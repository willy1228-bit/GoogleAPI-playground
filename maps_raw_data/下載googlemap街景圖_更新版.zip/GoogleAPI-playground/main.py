# Import google_streetview for the api module
import google_streetview.api
from dotenv import load_dotenv
import os
import argparse
import math
from os import path, makedirs
from google_streetview import helpers
import json
import csv

from utils.kml_handler import parse_location

# Load environment variables from .env file
load_dotenv()

# Get the API key from environment variable
# api_key = os.getenv('GOOGLE_API_KEY')
api_key = "Your_API_Key"

def download_links(dir_path, results, route_name, angle, metadata_file='metadata.json', metadata_status='status', status_ok='OK'):
    """Download Google Street View images from parameter queries if they are available.

    Args:
        dir_path (str):
        Path of directory to save downloads of images from :class:`api.results`.links
        metadata_file (str):
            Name of the file with extension to save the :class:`api.results`.metadata
        metadata_status (str):
        Key name of the status value from :class:`api.results`.metadata response from the metadata API request.
        status_ok (str):
        Value from the metadata API response status indicating that an image is available.
    """
    metadata = results.metadata
    if not path.isdir(dir_path):
        makedirs(dir_path)

    # (download) Download images if status from metadata is ok
    with open('GPS_coordinates.csv', 'a+', newline='') as csvfile:
        writer = csv.writer(csvfile)
        if not os.path.getsize('GPS_coordinates.csv'):
            writer.writerow(['name','address','latitude','longitude'])
        for i, url in enumerate(results.links):
            assert not metadata[i][metadata_status] == "REQUEST_DENIED", "The provided API key is invalid!"
            if metadata[i][metadata_status] == status_ok:
                file_name = str(route_name) + '_' + str(angle) + '_' + str(i) + '.jpg'
                file_path = path.join(dir_path, file_name)
                metadata[i]['_file'] = path.basename(file_path) # add file reference
                helpers.download(url, file_path)
                writer.writerow([file_name, '', metadata[i]['location']['lat'], metadata[i]['location']['lng']])
            else:
                print(f"{metadata[i]['location']} can not be downloaded!")

    # (metadata) Save metadata with file reference
    metadata_path = path.join(dir_path, metadata_file)
    with open(metadata_path, 'w') as out_file:
        json.dump(metadata, out_file, indent=4, ensure_ascii=False)

def create_params(location, heading):
    base_params = {
        'size': '640x360',
        'pitch': '0',
        'key': api_key
    }
    if isinstance(location, list):
        return [{**base_params, 'location': f"{loc[0]}, {loc[1]}", 'heading': str(h)} for loc, h in zip(location, heading)]

    return [{**base_params, 'location': f"{location[0]}, {location[1]}", 'heading': str(h)} for h in heading]


def get_street_view_images(params, route_name, angle, save_folder='downloads'):
    results = google_streetview.api.results(params)
    results.download_links = download_links
    results.download_links(save_folder, results, route_name, angle)
    results.save_links('links.txt')

def calculate_heading(coord1, coord2, angle_offset=0):
    lat1, lon1 = coord1
    lat2, lon2 = coord2
    delta_lon = lon2 - lon1
    x = math.sin(math.radians(delta_lon)) * math.cos(math.radians(lat2))
    y = (math.cos(math.radians(lat1)) * math.sin(math.radians(lat2)) -
         (math.sin(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.cos(math.radians(delta_lon))))
    heading = math.atan2(x, y)
    return (math.degrees(heading) + 360 + angle_offset) % 360


def process_kml_file(file_path, filename, raw_data_path):
    if os.path.exists(file_path):
        os.system(f'mv {os.path.join(raw_data_path, filename + ".kmz")} {os.path.join(raw_data_path, filename + ".zip")}')
        if os.path.exists(os.path.join(raw_data_path, filename + ".zip")):
            os.system(f'unzip {os.path.join(raw_data_path, filename + ".zip")} -d {os.path.join(raw_data_path, filename)}')
            os.system(f'rm {os.path.join(raw_data_path, filename + ".zip")}')


def main(args):
    filename = os.path.basename(args.file_path).split(".")[0]
    process_kml_file(args.file_path, filename, args.raw_data_path)

    # Update this line to pass both num_points and step_distance
    try:
        location = parse_location(os.path.join(args.raw_data_path, filename, "doc.kml"), 
                                route_name=args.route_name, 
                                num_points=args.num_points, 
                                step_distance=args.step_distance)

        save_folder = "./" + str(filename) if args.save_folder == "" else args.save_folder
        angle = [30, 150, 210, 330] if args.angle == -1 else [args.angle]
        for times in range(len(angle)):
            headings = [int(calculate_heading(location[i], location[i + 1], angle[times])) for i in range(len(location) - 1)]
            headings.append(headings[-1])

            params = create_params(location, headings)
            get_street_view_images(params, args.route_name, angle[times], save_folder=save_folder)
            print(f"The Google street view images at a {angle[times]}-degree angle have been downloaded!")
    except FileNotFoundError:
        print("Please check if there are any errors in your .kmz file name!")
    except AttributeError:
        print("Please check if there are any errors in the route name!")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--file_path', type=str, required=True, help='Path to the kml file')
    parser.add_argument('-r', '--route_name', type=str, required=True, help='Name of the route')
    
    # Create a mutually exclusive group for num_points and step_distance
    group = parser.add_mutually_exclusive_group()
    group.add_argument('-n', '--num_points', type=int, help='Number of points to interpolate')
    group.add_argument('-d', '--step_distance', type=float, default=10, help='Step distance for interpolation (in meters)')
    
    parser.add_argument('-s', '--save_folder', type=str, default="", help='Folder to save the street view images')
    parser.add_argument('-a', '--angle', type=int, default=-1, help='Angle offset from the forward direction (0-359 degrees)')
    parser.add_argument('--raw_data_path', type=str, default='maps_raw_data', help='Path to the raw data directory')
    args = parser.parse_args()
    main(args)